package cs350_maze;

public class Room {

}
