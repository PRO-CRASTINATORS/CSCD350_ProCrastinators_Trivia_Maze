package cs350_maze;

public class Door {

}
