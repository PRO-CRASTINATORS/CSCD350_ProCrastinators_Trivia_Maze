package cs350_maze;

public class Map {

	public boolean checkIfPlayerStuck(Object position) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean checkPosition(Object position) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean checkWin(Object position) {
		// TODO Auto-generated method stub
		return false;
	}

}
