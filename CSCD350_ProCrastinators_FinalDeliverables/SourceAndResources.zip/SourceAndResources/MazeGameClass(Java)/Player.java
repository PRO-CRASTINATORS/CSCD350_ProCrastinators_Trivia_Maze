package cs350_maze;

import java.util.Scanner;

public class Player {

	public void getNameFromUser(Scanner in) {
		// TODO Auto-generated method stub
		
	}

	public void selectDoor() {
		// TODO Auto-generated method stub
		
	}

	public Object getPosition() {
		// TODO Auto-generated method stub
		return null;
	}

}
