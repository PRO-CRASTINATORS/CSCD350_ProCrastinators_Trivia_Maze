package cs350_maze;

public class TriviaItem {
	
	private Question _q;
	private Answer _ans;
	

}
