package cs350_maze;

public class MazeMapBuilder {

	public MazeMapBuilder(DataBaseHandler dataBaseDriver) {
		// TODO Auto-generated constructor stub
	}

	public Map buildMap() {
		// TODO Auto-generated method stub
		return null;
	}

}
