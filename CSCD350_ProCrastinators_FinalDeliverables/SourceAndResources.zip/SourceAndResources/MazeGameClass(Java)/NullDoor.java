package cs350_maze;

public class NullDoor extends Door{

}
