README for ProCrastinators Trivia Maze

	Since this is a Flash based game built in the ActionScript language, and because an installer is included,
	you do not need to compile the code, simply run the installer and open the shortcut to the game.

	To compile and run manually, you must open Adobe Flash Professional CS6 and open the ProProject.fla
	file located in SourceAndResources>ProCrastinatorsTriviaMaze>srs folder. From there, go to file > publish
	in Adobe Flash Professional CS6, fill in any requirements needed to publish, and create an Air file for installing.
	
	It is important to include all important files, which are:
		ProProject.swf
		ProProject-app.xml
		lib (found in SourceAndResources>ProCrastinatorsTriviaMaze)
		triviaitems.db (found in SourceAndResources>ProCrastinatorsTriviaMaze)

	-KP