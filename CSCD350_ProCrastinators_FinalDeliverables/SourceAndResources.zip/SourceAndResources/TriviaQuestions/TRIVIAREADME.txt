TO ADD MORE TRIVIA:

1) Open the "AllTrivia.xlsx"
2)  Add or edit trivia as shown in previously existing data. Leave cell blank to represent "NULL". 

	DO NOT commas!

3) When finished, save the excel sheet like normal.
4) Use "Save as" to save again, but in a CSV format. After saving, close excel/ open office variant.
5) Open up the CSV in word/ office libre. Use the "Find and replace all" feature to replace all commas with semicolons. Resave, and you are done!