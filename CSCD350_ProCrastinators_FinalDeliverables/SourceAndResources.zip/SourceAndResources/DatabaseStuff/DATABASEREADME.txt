5/27/14
KP

Finished the code to read from a database in Java. This will need to be translated over to actionscript, if possible.
Current methods: 
	getTriviaByCategory(String Category) - returns ResultSet
	getAllTrivia() - returns ResultSet
	getCategories() - returns ResultSet
	printCategories(ResultSet rs) - void return
	printTrivia(ResultSet rs) - void return